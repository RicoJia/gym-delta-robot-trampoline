from setuptools import setup

setup(
    name="delta_robot_trampoline",
    version='0.0.1',
    packages=["resources"],
    python_requires='>=3',
    install_requires=['gym', 'pybullet', 'numpy']
)
